FARMERS MILK - ANDROID STUDIO PROJECT

This is an Android Studio source project wrapping the Farmers Milk prototype in a WebView.
Configured defaults in the included app:
- Cow milk price: Rs 60/litre
- English and Telugu interface
- WhatsApp order number: 918639056147
- Morning/evening delivery options

IMPORTANT LIMITATIONS
- This ZIP is source code, not an APK installer.
- Orders and settings are saved only on each customer's own device/browser storage. There is no shared online admin dashboard or cloud order database yet.
- UPI payment is not processed or verified inside the app.
- Test the app thoroughly before using it for real customers.

HOW TO BUILD AN APK
1. On a computer, install Android Studio and a compatible JDK (Android Studio includes one).
2. Open this folder (FarmersMilkAndroid) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When the build completes, use the notification link to locate the APK. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.
6. For Google Play, build a signed Android App Bundle (AAB) and complete the current Play Console registration, testing, and policy requirements.

The project uses Android Gradle Plugin 8.7.3. Android Studio may request a compatible Gradle version during sync.
